#include "Engine.h" 
#include <iostream> 
#include <Renderer/Program.h>
#include <Renderer/Material.h>

int main(int argc, char** argv)
{
	LOG("Application Started...");
	neu::InitializeMemory();
	neu::SetFilePath("../Assets");

	neu::Engine::Instance().Initialize();
	neu::Engine::Instance().Register();
	LOG("Engine Initialized");
	
	neu::g_renderer.CreateWindow("Neumont", 800, 600);

	neu::g_gui.Initialize(neu::g_renderer);

	auto scene = neu::g_resources.Get<neu::Scene>("scenes/cubemap.scn");

	glm::vec3 rot = {0,0,0};
	float ri = 1.04f;
	float interpolation = 0.5;

	bool quit = false;
	while (!quit)
	{
		neu::Engine::Instance().Update();
		neu::g_gui.BeginFrame(neu::g_renderer);

		if (neu::g_inputSystem.GetKeyState(neu::key_escape) == neu::InputSystem::KeyState::Pressed) quit = true;

		auto actor1 = scene->GetActorFromName("Light");
		if (actor1)
		{
			actor1->m_transform.position = rot;
		}

		auto program = neu::g_resources.Get<neu::Program>("shaders/FX/reflection_refraction.prog");
		if (program)
		{
			program->Use();
			program->SetUniform("ri", ri);
			program->SetUniform("interpolation", interpolation);
		}

		ImGui::Begin("Transform");
		ImGui::DragFloat3("Rotation", &rot[0]);
		ImGui::SliderFloat("Interpolation", &interpolation, 0, 1);
		ImGui::SliderFloat("RI", &ri, 1, 2);
		ImGui::End();

		//auto actor2 = scene->GetActorFromName("Squirrel");
		//if (actor2)
		//{
		//	actor2->m_transform.rotation = math::EulerToQuaternion(rot);
			//actor1->m_transform.rotation.y += neu::g_time.deltaTime * 30;
		//}
		//auto actor3 = scene->GetActorFromName("Box");

		scene->Update();

		neu::g_renderer.BeginFrame();

		scene->PreRender(neu::g_renderer);
		scene->Render(neu::g_renderer);
		neu::g_gui.Draw();

		neu::g_renderer.EndFrame();
		neu::g_gui.EndFrame();

	}
	scene->RemoveAll();
	neu::Engine::Instance().Shutdown();

	return 0;
}